# Buzzer-Button
Contributors: Toni Klätke  
Tags: buzzer, buzz, buzzing, fun, button, gamification
Requires at least: 4.0  
Tested up to: 5.6.1 
License: GPLv2 or later  
License URI: http://www.gnu.org/licenses/gpl-2.0.html  

Become a Buzzer Button in different Sizes and Styles.

## Description
This plugin enables you to display the Buzzer.Best button on your site. The plugin can easy implement with a shortcode.

### Usage 
Integrate the Shortcode [buzzer_button] - [buzzer_small] [buzzer_yellow] in WordPress and you get the Buzzer.Best in Spezial Mini Embed Version with Sound and Touch Effects and in different Colors. Easy to integrate. Use the Buzzer as Special CTA-Button or for Gamification in your Blog.

## Screenshots

1. Homepage - Header you can see runing Buzzer Button Plugin

