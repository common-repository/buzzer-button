<?php
/**
 * Plugin Name: Buzzer Button
 * Plugin URI: https://buzzer.best/wordpress-plugin
 * Description: Thanks for using the Buzzer.Best Button. With the Following Shortcodes you integrate the Buzzer Button: [buzzer_button] - [buzzer_small] - [buzzer_yellow]
 * Version: 1.0
 * Text Domain: buzzer.best
 * Author: Toni Klätke
 * Author URI: https://klaetke.com
 */
 
 function klaetkebuzz_wordpress_plugin_demo($atts) {
	$Content .= '<iframe style="border: none; width:125px;height:125px;" src="https://buzzer.best/widget"></iframe>';
	 
    return $Content;
}

add_shortcode('buzzer_button', 'klaetkebuzz_wordpress_plugin_demo');

 function klaetkebuzzs_wordpress_plugin_demo($atts) {
	$Content .= '<iframe style="border: none; width:50px;height:50px;" src="https://buzzer.best/widget"></iframe>';
	 
    return $Content;
}

add_shortcode('buzzer_small', 'klaetkebuzzs_wordpress_plugin_demo');

 function klaetkebuzzflex_wordpress_plugin_demo($atts) {
	$Content .= '<iframe style="border: none; width:50px;height:50px;" src="https://buzzer.best/widget-yellow"></iframe>';
	 
    return $Content;
}

add_shortcode('buzzer_yellow', 'klaetkebuzzflex_wordpress_plugin_demo');